package com.LibManageApp.booksauthors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooksAuthorsApplication {
    public static void main(String[] args) {
        SpringApplication.run(BooksAuthorsApplication.class, args);
    }
}

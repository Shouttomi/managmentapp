package com.LibManageApp.booksauthors.entity;

import javax.persistence.*;
import java.util.List;

@Entity
public class Author {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String bio;

    @OneToMany(mappedBy = "author")
    private List<Book> books;

    // Getters and Setters
}
